#pragma once
/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#define AWS_CRT_CPP_VERSION "0.24.1"
#define AWS_CRT_CPP_VERSION_MAJOR 0
#define AWS_CRT_CPP_VERSION_MINOR 24
#define AWS_CRT_CPP_VERSION_PATCH 1
#define AWS_CRT_CPP_GIT_HASH "27c812d17f6478af9a330ba1cdd6c371a9e88b82"
